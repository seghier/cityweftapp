
import { CityweftPayload, ApiResponse } from '../types';

const API_URL = "https://api.cityweft.com/v1/context";

export const requestCityweftData = async (payload: CityweftPayload, apiKey: string): Promise<string> => {
  const response = await fetch(API_URL, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(payload)
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    throw new Error(errorData.message || `API Error: ${response.status} ${response.statusText}`);
  }

  const data: ApiResponse = await response.json();
  if (!data.downloadUrl) {
    throw new Error("The API did not provide a download link. Please check your credentials or region size.");
  }

  return data.downloadUrl;
};

export const downloadFile = async (url: string, filename: string) => {
  try {
    const response = await fetch(url);
    if (!response.ok) throw new Error("Download failed");
    
    const blob = await response.blob();
    const downloadUrl = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = downloadUrl;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(downloadUrl);
    document.body.removeChild(a);
  } catch (err) {
    // Fallback if CORS prevents blob fetch
    window.open(url, '_blank');
  }
};
