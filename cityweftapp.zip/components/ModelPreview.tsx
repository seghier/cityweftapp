import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls';
import {
  X, RotateCcw, Eye, Download, Loader2, Image as ImageIcon,
  Box, Edit2, Check, ChevronDown, Layers, ChevronLeft, ChevronRight, EyeOff
} from 'lucide-react';
import { generateRender, GeminiModel } from '../services/nanobanana';

interface GeometryData {
  type: string;
  geometryType: string;
  meshes?: Array<{
    vertices: number[];
    descriptor?: {
      type?: string;
      pathType?: string;
      id?: string;
      [key: string]: any;
    };
  }>;
  nodes?: Array<{
    type?: string;
    x?: number;
    y?: number;
    z?: number;
    scale?: number;
    rotation?: number;
    [key: string]: any;
  }>;
}

interface ApiResponse {
  origin: [number, number];
  geometry: GeometryData[];
}

interface ModelPreviewProps {
  isOpen: boolean;
  onClose: () => void;
  geometryData: ApiResponse | null;
  onConfirmDownload: () => void;
  isLoading?: boolean;
  nanoBananaApiKey?: string;
  locationName?: string;
}

const COLORS = {
  buildings: '#FFFFFF',
  surface: {
    roadway: '#808080',
    asphalt: '#333333',
    grass: '#7CFC00',
    water: '#ADD8E6',
    footway: '#B092BC',
    default: '#CCCCCC'
  },
  infrastructure: {
    tree: '#228B22',
    shrubbery: '#8FBC8F',
    bench: '#A0522D',
    utilityPole: '#696969',
    default: '#AAAAAA'
  },
  barriers: '#8B4513',
  topography: '#654321'
};

const ModelPreview: React.FC<ModelPreviewProps> = ({
  isOpen,
  onClose,
  geometryData,
  onConfirmDownload,
  isLoading = false,
  nanoBananaApiKey,
  locationName
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const meshGroupRef = useRef<THREE.Group | null>(null);
  const layerGroupsRef = useRef<Record<string, THREE.Group>>({});
  const [stats, setStats] = useState({ meshCount: 0, vertexCount: 0 });

  // Rendering State
  const [activeTab, setActiveTab] = useState<'3d' | 'render'>('3d');
  const [renderedImageUrl, setRenderedImageUrl] = useState<string | null>(null);
  const [isRendering, setIsRendering] = useState(false);
  const [renderError, setRenderError] = useState<string | null>(null);

  const [originalImageUrl, setOriginalImageUrl] = useState<string | null>(null);
  const [sliderPosition, setSliderPosition] = useState(50);
  const sliderRef = useRef<HTMLDivElement>(null);

  // Prompt Editing State
  const [showPromptEditor, setShowPromptEditor] = useState(false);
  const [promptOverride, setPromptOverride] = useState<string>("");
  const [tempPrompt, setTempPrompt] = useState<string>("");
  const [selectedModel, setSelectedModel] = useState<GeminiModel>('gemini-3-pro-image-preview');

  // Layer Control State
  const [showLayers, setShowLayers] = useState(true);
  const [layerVisibility, setLayerVisibility] = useState({
    buildings: true,
    surface: true,
    vegetation: true,
    infrastructure: true,
    barriers: true,
    topography: true
  });

  useEffect(() => {
    // Reset prompt override when geometry data changes
    setPromptOverride("");
  }, [geometryData]);

  // Update Grid/Layer Visibility
  useEffect(() => {
    Object.entries(layerVisibility).forEach(([key, visible]) => {
      const group = layerGroupsRef.current[key];
      if (group) group.visible = visible;
    });
  }, [layerVisibility]);

  const generateDefaultPrompt = () => {
    let smartPrompt = "Photorealistic render of an urban environment, architectural visualization, high fidelity to input layout, realistic building facades and textures, organic tree canopy, do not add new buildings, respect camera view and perspective, cinematic lighting, highly detailed, 8k resolution, day lighting";

    if (locationName) {
      smartPrompt = `Photorealistic render of ${locationName}, urban context, accurate architectural style, high fidelity to input layout, realistic materials, organic vegetation, do not add new buildings, respect camera view and perspective, cinematic lighting, 8k resolution`;
    }

    if (geometryData?.origin) {
      smartPrompt += `, located at coordinates ${geometryData.origin[0]}, ${geometryData.origin[1]}`;
    }
    return smartPrompt;
  };

  const handleOpenPromptEditor = () => {
    const currentPrompt = promptOverride || generateDefaultPrompt();
    setTempPrompt(currentPrompt);
    setShowPromptEditor(true);
  };

  const handleSavePrompt = () => {
    setPromptOverride(tempPrompt);
    setShowPromptEditor(false);
  };

  const handleSliderMove = (e: React.MouseEvent | React.TouchEvent) => {
    if (!sliderRef.current) return;
    const rect = sliderRef.current.getBoundingClientRect();
    const x = 'touches' in e ? e.touches[0].clientX : (e as React.MouseEvent).clientX;
    const position = ((x - rect.left) / rect.width) * 100;
    setSliderPosition(Math.min(100, Math.max(0, position)));
  };

  const handleRender = async () => {
    if (!rendererRef.current || !nanoBananaApiKey) return;

    setIsRendering(true);
    setRenderError(null);
    setRenderedImageUrl(null);
    setActiveTab('render');

    try {
      // Capture current view at high resolution (1376x768)
      // Store original size and aspect
      const originalSize = new THREE.Vector2();
      rendererRef.current.getSize(originalSize);
      const originalAspect = cameraRef.current.aspect;

      // Set high-res target size
      const targetWidth = 1376;
      const targetHeight = 768;

      // Resize renderer (buffer only, not style)
      rendererRef.current.setSize(targetWidth, targetHeight, false);
      if (cameraRef.current) {
        cameraRef.current.aspect = targetWidth / targetHeight;
        cameraRef.current.updateProjectionMatrix();
      }
      if (sceneRef.current && cameraRef.current) {
        rendererRef.current.render(sceneRef.current, cameraRef.current);
      }

      const canvas = rendererRef.current.domElement;
      const dataUrl = canvas.toDataURL('image/png');

      // Restore original size and aspect
      rendererRef.current.setSize(originalSize.x, originalSize.y, false);
      if (cameraRef.current) {
        cameraRef.current.aspect = originalAspect;
        cameraRef.current.updateProjectionMatrix();
      }
      if (sceneRef.current && cameraRef.current) {
        rendererRef.current.render(sceneRef.current, cameraRef.current);
      }

      setOriginalImageUrl(dataUrl); // Set immediate preview

      const blob = await (await fetch(dataUrl)).blob();

      // Construct Smart Prompt
      const smartPrompt = promptOverride || generateDefaultPrompt();

      console.log(`Generating render with prompt (${selectedModel}):`, smartPrompt);

      const result = await generateRender(blob, smartPrompt, nanoBananaApiKey, selectedModel);

      if (result.status === 'success') {
        setRenderedImageUrl(result.imageUrl);
      } else {
        setRenderError(result.error || "Rendering failed");
      }
    } catch (err) {
      setRenderError(err instanceof Error ? err.message : "Unknown error");
    } finally {
      setIsRendering(false);
    }
  };

  useEffect(() => {
    if (!isOpen || !containerRef.current || !geometryData) return;

    // Scene setup
    const scene = new THREE.Scene();
    // Create gradient background
    const canvas = document.createElement('canvas');
    canvas.width = 2;
    canvas.height = 512;
    const context = canvas.getContext('2d');
    if (context) {
      const gradient = context.createLinearGradient(0, 0, 0, 512);
      gradient.addColorStop(0, '#3b82f6'); // Zenith (Blue)
      gradient.addColorStop(1, '#e0f2fe'); // Horizon (White/Light Blue)
      context.fillStyle = gradient;
      context.fillRect(0, 0, 2, 512);
      const texture = new THREE.CanvasTexture(canvas);
      scene.background = texture;
    } else {
      scene.background = new THREE.Color(0xe0f2fe);
    }
    sceneRef.current = scene;

    // Camera setup
    const camera = new THREE.PerspectiveCamera(
      60,
      containerRef.current.clientWidth / containerRef.current.clientHeight,
      0.1,
      10000 // Increased far clipping plane
    );
    camera.position.set(50, 80, 50);
    cameraRef.current = camera;

    // Renderer setup
    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: true,
      preserveDrawingBuffer: true // Required for screenshot capture
    });
    renderer.setSize(containerRef.current.clientWidth, containerRef.current.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = false;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    containerRef.current.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Controls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.maxPolarAngle = Math.PI / 2;
    controlsRef.current = controls;

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.8); // Increased intensity
    scene.add(ambientLight);

    const hemisphereLight = new THREE.HemisphereLight(0xffffff, 0x0f172a, 0.6); // Sky color, Ground color, Intensity
    scene.add(hemisphereLight);

    const directionalLight = new THREE.DirectionalLight(0xffffff, 1.0);
    directionalLight.position.set(100, 200, 50);
    directionalLight.castShadow = false;
    directionalLight.shadow.mapSize.width = 2048;
    directionalLight.shadow.mapSize.height = 2048;
    directionalLight.shadow.camera.left = -200;
    directionalLight.shadow.camera.right = 200;
    directionalLight.shadow.camera.top = 200;
    directionalLight.shadow.camera.bottom = -200;
    scene.add(directionalLight);

    // Add Fill Light for better 3D readability with white buildings
    const fillLight = new THREE.DirectionalLight(0xffffff, 0.4);
    fillLight.position.set(-100, 50, -100);
    scene.add(fillLight);

    // Process geometry
    const meshGroup = new THREE.Group();
    meshGroupRef.current = meshGroup;

    // Create separate groups for layers
    const layers: Record<string, THREE.Group> = {
      buildings: new THREE.Group(),
      surface: new THREE.Group(),
      vegetation: new THREE.Group(),
      infrastructure: new THREE.Group(),
      barriers: new THREE.Group(),
      topography: new THREE.Group()
    };
    layerGroupsRef.current = layers;

    // Add all layers to main group
    Object.values(layers).forEach(group => meshGroup.add(group));

    let totalMeshes = 0;
    let totalVertices = 0;

    // Define geometries for different node types
    const geometries: Record<string, THREE.BufferGeometry> = {
      tree_trunk: new THREE.CylinderGeometry(0.15, 0.2, 1, 5),
      tree_foliage: new THREE.IcosahedronGeometry(1, 0),
      shrubbery: new THREE.IcosahedronGeometry(1, 0),
      utilityPole: new THREE.CylinderGeometry(0.1, 0.1, 8, 8),
      bench: new THREE.BoxGeometry(2, 1, 1),
      default: new THREE.BoxGeometry(1, 1, 1)
    };

    // Adjust pivot points to bottom
    Object.values(geometries).forEach(geo => {
      // Check if already translated (hacky check but safe for this local scope)
      if (!geo.userData.translated) {
        geo.computeBoundingBox();
        const height = geo.boundingBox!.max.y - geo.boundingBox!.min.y;
        geo.translate(0, height / 2, 0);
        geo.userData.translated = true;
      }
    });

    const instances: Record<string, Array<{ position: THREE.Vector3, scale: THREE.Vector3, color: string }>> = {
      tree_trunk: [],
      tree_foliage: [],
      shrubbery: [],
      utilityPole: [],
      bench: [],
      default: []
    };

    geometryData.geometry.forEach((geomData) => {
      const { type, geometryType } = geomData;

      if (geometryType === 'meshes' && geomData.meshes) {
        geomData.meshes.forEach((mesh) => {
          if (!mesh.vertices || mesh.vertices.length === 0) return;

          const vertices = new Float32Array(mesh.vertices);
          const geometry = new THREE.BufferGeometry();
          geometry.setAttribute('position', new THREE.BufferAttribute(vertices, 3));
          geometry.computeVertexNormals();

          let color = COLORS.buildings;
          let targetLayer = layers.infrastructure; // default fallback

          if (type === 'buildings') {
            color = COLORS.buildings;
            targetLayer = layers.buildings;
          } else if (type === 'surface') {
            const surfaceType = mesh.descriptor?.pathType || mesh.descriptor?.type || 'default';
            color = COLORS.surface[surfaceType as keyof typeof COLORS.surface] || COLORS.surface.default;
            targetLayer = layers.surface;
          } else if (type === 'infrastructure') {
            const infraType = mesh.descriptor?.type || 'default';
            color = COLORS.infrastructure[infraType as keyof typeof COLORS.infrastructure] || COLORS.infrastructure.default;
            targetLayer = layers.infrastructure;
          } else if (type === 'barriers') {
            color = COLORS.barriers;
            targetLayer = layers.barriers;
          } else if (type === 'topography') {
            color = COLORS.topography;
            targetLayer = layers.topography;
          }

          const material = new THREE.MeshStandardMaterial({
            color: new THREE.Color(color),
            flatShading: false,
            side: THREE.DoubleSide,
            metalness: 0.1,
            roughness: 0.8
          });

          const meshObject = new THREE.Mesh(geometry, material);
          meshObject.castShadow = false;
          meshObject.receiveShadow = false;

          // Store metadata
          meshObject.userData = {
            type,
            descriptor: mesh.descriptor
          };

          targetLayer.add(meshObject);

          // Add Edges for Buildings
          if (type === 'buildings') {
            const edges = new THREE.EdgesGeometry(geometry);
            const line = new THREE.LineSegments(
              edges,
              new THREE.LineBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.2 })
            );
            meshObject.add(line);
          }

          totalMeshes++;
          totalVertices += vertices.length / 3;
        });
      }

      if (geometryType === 'nodes' && geomData.nodes) {
        geomData.nodes.forEach((node) => {
          const x = node.x || 0;
          const y = node.y || 0;
          const z = node.z || 0;
          const scale = node.scale || 1;
          // Normalize node type: Check instanceType first, then type, then default
          const rawType = node.instanceType || node.type || 'default';
          const nodeType = rawType.toLowerCase().trim();

          // Known non-tree types that have their own specific rendering or should be ignored if we had them
          const knownNonTreeTypes = ['shrubbery', 'utilitypole', 'bench', 'hydrant', 'rock', 'illustration', 'adcolumn', 'ac_unit'];

          // AGGRESSIVE FALLBACK: 
          // If it is explicitly a tree OR if it is NOT one of the known non-tree types, render it as a TREE.
          // This ensures that "default" (grey cubes) and other unknown types become trees.
          const isTree = nodeType.includes('tree') || !knownNonTreeTypes.includes(nodeType);

          if (isTree) {
            // Special handling for tree: Trunk + Foliage
            const treeScale = Math.max(scale, 1);

            // Trunk: Brown, thinner, cylinder
            // Increased size by 25% from previous small size
            instances['tree_trunk'].push({
              position: new THREE.Vector3(x, y, z),
              scale: new THREE.Vector3(treeScale * 0.0625, treeScale * 0.125, treeScale * 0.0625),
              color: '#5D4037' // Wood
            });

            // Foliage: Green, sphere on top (Icosahedron for low poly look)
            // Position foliage higher up on the trunk
            // Increased size by 25%
            instances['tree_foliage'].push({
              position: new THREE.Vector3(x, y + (treeScale * 0.156), z),
              scale: new THREE.Vector3(treeScale * 0.156, treeScale * 0.156, treeScale * 0.156),
              color: COLORS.infrastructure.tree
            });

          } else {
            // It is a known non-tree type (shrubbery, bench, utilityPole)
            let category = 'default';

            if (['shrubbery', 'utilitypole', 'bench'].includes(nodeType)) {
              if (nodeType === 'utilitypole') category = 'utilityPole';
              else category = nodeType;
            } else {
              category = 'default';
            }

            // Fallback for color lookup using the normalized type or original type
            const infraColor = COLORS.infrastructure[nodeType as keyof typeof COLORS.infrastructure] ||
              COLORS.infrastructure[rawType as keyof typeof COLORS.infrastructure] ||
              COLORS.infrastructure.default;

            const finalScale = Math.max(scale, 1) * 0.5;

            instances[category].push({
              position: new THREE.Vector3(x, y, z),
              scale: new THREE.Vector3(finalScale, finalScale, finalScale),
              color: infraColor
            });
          }
        });
      }
    });

    // Create InstancedMeshes
    const dummy = new THREE.Object3D();
    const whiteColor = new THREE.Color();

    Object.entries(instances).forEach(([category, items]) => {
      if (items.length === 0) return;

      const geometry = geometries[category] || geometries['default'];
      const material = new THREE.MeshStandardMaterial({
        color: 0xffffff, // Base color white, multiplied by instance color
        flatShading: true,
        roughness: 0.8,
        metalness: 0.1
      });

      const instancedMesh = new THREE.InstancedMesh(geometry, material, items.length);
      instancedMesh.castShadow = false;
      instancedMesh.receiveShadow = false;

      items.forEach((item, index) => {
        dummy.position.copy(item.position);
        dummy.scale.copy(item.scale);
        dummy.rotation.set(0, Math.random() * Math.PI * 2, 0); // Random rotation
        dummy.updateMatrix();

        instancedMesh.setMatrixAt(index, dummy.matrix);
        instancedMesh.setColorAt(index, whiteColor.set(item.color));
      });

      instancedMesh.instanceMatrix.needsUpdate = true;
      if (instancedMesh.instanceColor) instancedMesh.instanceColor.needsUpdate = true;

      // Assign to correct layer group
      let targetLayer = layers.infrastructure;
      if (['tree_trunk', 'tree_foliage', 'shrubbery'].includes(category)) {
        targetLayer = layers.vegetation;
      } else {
        targetLayer = layers.infrastructure;
      }
      targetLayer.add(instancedMesh);

      totalMeshes++; // Count instances as meshes for stats 
      totalVertices += (geometry.attributes.position.count * items.length);
    });

    scene.add(meshGroup);
    setStats({ meshCount: totalMeshes, vertexCount: totalVertices });

    // Center and fit camera to model
    const box = new THREE.Box3().setFromObject(meshGroup);
    const center = box.getCenter(new THREE.Vector3());
    const size = box.getSize(new THREE.Vector3());
    const maxDim = Math.max(size.x, size.y, size.z);
    const fov = camera.fov * (Math.PI / 180);
    let cameraZ = Math.abs(maxDim / 2 / Math.tan(fov / 2));
    cameraZ *= 1.5; // Add some padding

    camera.position.set(center.x + cameraZ * 0.5, center.y + cameraZ * 0.8, center.z + cameraZ * 0.5);
    camera.lookAt(center);
    controls.target.copy(center);
    controls.update();

    // Animation loop
    const animate = () => {
      requestAnimationFrame(animate);
      controls.update();
      renderer.render(scene, camera);
    };
    animate();

    // Handle resize
    const handleResize = () => {
      if (!containerRef.current || !camera || !renderer) return;
      camera.aspect = containerRef.current.clientWidth / containerRef.current.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(containerRef.current.clientWidth, containerRef.current.clientHeight);
    };
    window.addEventListener('resize', handleResize);

    // Apply initial visibility
    Object.entries(layerVisibility).forEach(([key, visible]) => {
      const group = layerGroupsRef.current[key];
      if (group) group.visible = visible;
    });

    // Cleanup
    return () => {
      window.removeEventListener('resize', handleResize);
      if (containerRef.current && renderer.domElement) {
        containerRef.current.removeChild(renderer.domElement);
      }
      renderer.dispose();
      controls.dispose();

      // Dispose geometries and materials
      meshGroup.traverse((object) => {
        if (object instanceof THREE.Mesh) {
          object.geometry.dispose();
          if (Array.isArray(object.material)) {
            object.material.forEach(mat => mat.dispose());
          } else {
            object.material.dispose();
          }
        }
      });
    };
  }, [isOpen, geometryData]); // eslint-disable-next-line react-hooks/exhaustive-deps

  const handleReset = () => {
    if (cameraRef.current && controlsRef.current && meshGroupRef.current) {
      const box = new THREE.Box3().setFromObject(meshGroupRef.current);
      const center = box.getCenter(new THREE.Vector3());
      const size = box.getSize(new THREE.Vector3());
      const maxDim = Math.max(size.x, size.y, size.z);
      const fov = cameraRef.current.fov * (Math.PI / 180);
      let cameraZ = Math.abs(maxDim / 2 / Math.tan(fov / 2));
      cameraZ *= 1.5;

      cameraRef.current.position.set(center.x + cameraZ * 0.5, center.y + cameraZ * 0.8, center.z + cameraZ * 0.5);
      cameraRef.current.lookAt(center);
      controlsRef.current.target.copy(center);
      controlsRef.current.update();
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[3000] flex items-center justify-center p-6 bg-slate-950/80 backdrop-blur-xl animate-in fade-in duration-300">
      <div className="glass-panel w-full max-w-7xl h-[90vh] rounded-[40px] shadow-2xl border border-white/10 flex flex-col overflow-hidden animate-in zoom-in-95 duration-300">
        {/* Header with Tabs */}
        <div className="flex items-center justify-between p-6 border-b border-white/5">
          <div className="flex items-center gap-4">
            <h2 className="text-xl font-black text-white tracking-tight flex items-center gap-3">
              <Eye className="w-6 h-6 text-blue-500" />
              Model Preview
            </h2>

            {/* Prompt Editor Button - Only visible in Render tab or when not rendering */}
            <button
              onClick={handleOpenPromptEditor}
              className="flex items-center gap-2 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-md text-xs font-bold transition-all ml-4 border border-white/10"
              title="Edit Rendering Prompt"
            >
              <Edit2 className="w-3.5 h-3.5" />
              Edit Prompt
            </button>

            <div className="flex bg-slate-900/50 rounded-lg p-1 ml-4">
              <button
                onClick={() => setActiveTab('3d')}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-xs font-bold transition-all ${activeTab === '3d'
                  ? 'bg-blue-500 text-white shadow-lg'
                  : 'text-slate-400 hover:text-white'
                  }`}
              >
                <Box className="w-3.5 h-3.5" />
                3D View
              </button>
              <button
                onClick={() => setActiveTab('render')}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-xs font-bold transition-all ${activeTab === 'render'
                  ? 'bg-purple-500 text-white shadow-lg'
                  : 'text-slate-400 hover:text-white'
                  }`}
              >
                <ImageIcon className="w-3.5 h-3.5" />
                Render
              </button>
            </div>
          </div>

          <button onClick={onClose} className="p-2 hover:bg-white/5 rounded-full text-slate-500 hover:text-white transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Area */}
        <div className="flex-1 relative bg-slate-950 overflow-hidden">

          {/* 3D Viewport */}
          <div className={`absolute inset-0 ${activeTab === '3d' ? 'visible' : 'invisible'}`} ref={containerRef}>
            {/* 3D Canvas is appended here by existing useEffect */}

            {/* Layer Control Panel */}
            <div className={`absolute left-6 top-6 transition-all duration-300 z-10 flex gap-2 pointer-events-none ${showLayers ? 'translate-x-0' : '-translate-x-[calc(100%-40px)]'}`}>
              <div className={`bg-slate-900/80 backdrop-blur-md rounded-2xl border border-white/10 overflow-hidden shadow-xl transition-all pointer-events-auto ${showLayers ? 'w-64 p-4' : 'w-0 p-0 opacity-0'}`}>
                <div className="flex items-center gap-2 mb-4 text-slate-400 pb-3 border-b border-white/5">
                  <Layers className="w-4 h-4" />
                  <span className="text-xs font-black uppercase tracking-widest">Scene Layers</span>
                </div>
                <div className="space-y-2">
                  {[
                    { id: 'buildings', label: 'Buildings' },
                    { id: 'surface', label: 'Surface & Roads' },
                    { id: 'vegetation', label: 'Vegetation' },
                    { id: 'infrastructure', label: 'Infrastructure' },
                    { id: 'barriers', label: 'Barriers' },
                    { id: 'topography', label: 'Topography' }
                  ].map(layer => (
                    <button
                      key={layer.id}
                      onClick={() => setLayerVisibility(prev => ({ ...prev, [layer.id]: !prev[layer.id as keyof typeof layerVisibility] }))}
                      className={`w-full flex items-center justify-between p-2 rounded-lg transition-all ${layerVisibility[layer.id as keyof typeof layerVisibility]
                        ? 'bg-blue-600/20 text-blue-200'
                        : 'bg-transparent text-slate-500 hover:text-slate-300 hover:bg-white/5'}`}
                    >
                      <span className="text-xs font-bold">{layer.label}</span>
                      {layerVisibility[layer.id as keyof typeof layerVisibility]
                        ? <Eye className="w-3.5 h-3.5" />
                        : <EyeOff className="w-3.5 h-3.5" />}
                    </button>
                  ))}
                </div>
              </div>

              {/* Toggle Button */}
              <button
                onClick={() => setShowLayers(!showLayers)}
                className="h-10 w-10 bg-slate-900/80 backdrop-blur-md rounded-xl border border-white/10 flex items-center justify-center text-slate-400 hover:text-white hover:bg-slate-800 transition-all pointer-events-auto shadow-lg"
              >
                {showLayers ? <ChevronLeft className="w-5 h-5" /> : <Layers className="w-5 h-5" />}
              </button>
            </div>

            {/* Overlay Controls for 3D View */}
            <div className="absolute bottom-6 left-6 flex gap-4 pointer-events-none">
              <div className="bg-slate-900/80 backdrop-blur-md px-4 py-2 rounded-xl border border-white/10 pointer-events-auto">
                <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Stats</div>
                <div className="text-xs text-white font-mono">
                  {stats.meshCount} meshes • {stats.vertexCount.toLocaleString()} vertices
                </div>
              </div>
            </div>

            <div className="absolute bottom-6 right-6 flex gap-3 pointer-events-none">
              <button
                onClick={() => controlsRef.current?.reset()}
                className="bg-slate-900/80 backdrop-blur-md p-3 rounded-xl border border-white/10 text-white hover:bg-white/10 transition-all pointer-events-auto"
                title="Reset View"
              >
                <RotateCcw className="w-5 h-5" />
              </button>

              {nanoBananaApiKey && (
                <div className="flex gap-2 pointer-events-auto shadow-lg rounded-xl">
                  <div className="relative group">
                    <select
                      value={selectedModel}
                      onChange={(e) => setSelectedModel(e.target.value as GeminiModel)}
                      className="appearance-none bg-slate-900/80 backdrop-blur-md pl-4 pr-8 py-3 rounded-l-xl border border-white/10 text-white font-bold text-xs uppercase tracking-wider hover:bg-white/10 transition-all focus:outline-none focus:ring-2 focus:ring-purple-500/50 cursor-pointer"
                      title="Select Rendering Model"
                    >
                      <option value="gemini-3-pro-image-preview" className="bg-slate-900 text-white">Gemini 3 Pro</option>
                      <option value="gemini-2.5-flash-image" className="bg-slate-900 text-white">Gemini 2.5 Flash</option>
                    </select>
                    <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
                  </div>

                  <button
                    onClick={handleRender}
                    className="bg-purple-600/90 backdrop-blur-md px-4 py-3 rounded-r-xl border-l border-white/10 text-white font-bold text-xs uppercase tracking-wider hover:bg-purple-500 transition-all flex items-center gap-2"
                  >
                    <ImageIcon className="w-4 h-4" />
                    Render
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Render Viewport */}
          {activeTab === 'render' && (
            <div className="absolute inset-0 flex items-center justify-center p-8 bg-slate-950">

              {/* Prompt Editor Overlay */}
              {showPromptEditor && (
                <div className="absolute inset-0 z-50 bg-slate-950/90 backdrop-blur-sm flex items-center justify-center p-8 animate-in fade-in duration-200">
                  <div className="w-full max-w-2xl bg-slate-900 border border-white/10 rounded-2xl p-6 shadow-2xl flex flex-col gap-4">
                    <div className="flex justify-between items-center">
                      <h3 className="text-lg font-bold text-white flex items-center gap-2">
                        <Edit2 className="w-4 h-4 text-purple-400" />
                        Edit Render Prompt
                      </h3>
                      <button onClick={() => setShowPromptEditor(false)} className="text-slate-500 hover:text-white">
                        <X className="w-5 h-5" />
                      </button>
                    </div>

                    <textarea
                      value={tempPrompt}
                      onChange={(e) => setTempPrompt(e.target.value)}
                      className="w-full h-32 bg-slate-800 border border-white/10 rounded-xl p-4 text-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 resize-none"
                      placeholder="Enter description..."
                    />

                    <div className="flex justify-end gap-3">
                      <button
                        onClick={() => setShowPromptEditor(false)}
                        className="px-4 py-2 hover:bg-white/5 text-slate-400 rounded-lg text-xs font-bold"
                      >
                        Cancel
                      </button>
                      <button
                        onClick={handleSavePrompt}
                        className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white rounded-lg text-xs font-bold flex items-center gap-2"
                      >
                        <Check className="w-3.5 h-3.5" />
                        Save Prompt
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {isRendering ? (
                <div className="relative w-full h-full flex items-center justify-center rounded-2xl overflow-hidden border border-white/10">
                  {/* Immediate Preview Background */}
                  {originalImageUrl && (
                    <img
                      src={originalImageUrl}
                      className="absolute inset-0 w-full h-full object-cover opacity-50 blur-sm brightness-50"
                      alt="Processing Preview"
                    />
                  )}

                  <div className="flex flex-col items-center gap-4 animate-in fade-in zoom-in duration-300 relative z-10">
                    <div className="relative">
                      <div className="absolute inset-0 bg-purple-500/20 blur-xl rounded-full animate-pulse" />
                      <Loader2 className="w-12 h-12 text-purple-500 animate-spin relative z-10" />
                    </div>
                    <div className="text-center">
                      <h3 className="text-white font-bold text-lg">Rendering Scene...</h3>
                      <p className="text-slate-400 text-sm">Powered by Google Gemini</p>
                      {locationName && <p className="text-slate-500 text-xs mt-1">Context: {locationName}</p>}
                    </div>
                  </div>
                </div>
              ) : renderError ? (
                <div className="text-center max-w-md p-6 bg-red-500/10 border border-red-500/20 rounded-2xl">
                  <h3 className="text-red-400 font-bold mb-2">Rendering Failed</h3>
                  <p className="text-slate-300 text-sm">{renderError}</p>
                  <button
                    onClick={handleRender}
                    className="mt-4 px-4 py-2 bg-red-500/20 hover:bg-red-500/30 text-red-300 rounded-lg text-xs font-bold uppercase tracking-wider transition-colors"
                  >
                    Try Again
                  </button>
                </div>
              ) : renderedImageUrl && originalImageUrl ? (
                <div
                  className="relative w-full h-full rounded-lg shadow-2xl border border-white/10 overflow-hidden cursor-ew-resize select-none"
                  ref={sliderRef}
                  onMouseMove={handleSliderMove}
                  onTouchMove={handleSliderMove}
                >
                  {/* Original Image (Before) */}
                  <img
                    src={originalImageUrl}
                    alt="Original View"
                    className="absolute inset-0 w-full h-full object-cover"
                  />
                  <div className="absolute top-4 left-4 bg-black/50 backdrop-blur px-2 py-1 rounded text-[10px] font-bold text-white uppercase tracking-wider pointer-events-none">
                    Original
                  </div>

                  {/* Rendered Image (After) - Clipped */}
                  <div
                    className="absolute inset-0 w-full h-full overflow-hidden"
                    style={{ clipPath: `inset(0 ${100 - sliderPosition}% 0 0)` }}
                  >
                    <img
                      src={renderedImageUrl}
                      alt="Gemini Render"
                      className="absolute inset-0 w-full h-full object-cover"
                    />
                    <div className="absolute top-4 right-4 bg-purple-600/80 backdrop-blur px-2 py-1 rounded text-[10px] font-bold text-white uppercase tracking-wider pointer-events-none">
                      Gemini Render
                    </div>
                  </div>

                  {/* Slider Handle */}
                  <div
                    className="absolute top-0 bottom-0 w-1 bg-white cursor-ew-resize z-20 shadow-[0_0_10px_rgba(0,0,0,0.5)]"
                    style={{ left: `${sliderPosition}%` }}
                  >
                    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-8 bg-white rounded-full shadow-lg flex items-center justify-center">
                      <div className="flex gap-0.5">
                        <div className="w-0.5 h-3 bg-slate-400"></div>
                        <div className="w-0.5 h-3 bg-slate-400"></div>
                      </div>
                    </div>
                  </div>

                  {/* Download Action */}
                  <div className="absolute bottom-8 right-8 z-30">
                    <a
                      href={renderedImageUrl}
                      download="gemini_render.png"
                      className="flex items-center gap-2 px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white rounded-lg font-bold text-sm transition-colors shadow-lg"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <Download className="w-4 h-4" />
                      Save Render
                    </a>
                  </div>
                </div>
              ) : (
                <div className="text-center text-slate-500">
                  <ImageIcon className="w-16 h-16 mx-auto mb-4 opacity-20" />
                  <p>No render generated yet.</p>
                  <button
                    onClick={handleRender}
                    className="mt-4 text-purple-400 hover:text-purple-300 font-bold text-sm"
                  >
                    Start Render from 3D View
                  </button>
                </div>
              )}
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="p-6 border-t border-white/5 bg-slate-900/50 backdrop-blur-sm flex justify-between items-center">
          <div className="flex gap-4 text-[10px] font-mono text-slate-500">
            <div>LMB: ROTATE</div>
            <div>RMB: PAN</div>
            <div>SCROLL: ZOOM</div>
          </div>

          <button
            onClick={onConfirmDownload}
            disabled={isLoading}
            className="flex items-center gap-2 px-6 py-3 bg-white text-slate-900 rounded-xl font-bold text-xs uppercase tracking-wider hover:bg-blue-50 transition-colors shadow-lg shadow-white/5 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isLoading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Processing...
              </>
            ) : (
              <>
                <Download className="w-4 h-4" />
                Download Model
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ModelPreview;
