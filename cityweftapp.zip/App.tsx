import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Search,
  Navigation,
  MapPin,
  Loader2,
  X,
  Download,
  Key,
  ShieldCheck,
  Eye,
  EyeOff
} from 'lucide-react';
import { AppSettings, ExportFormat, AppStatus, CityweftPayload } from './types';
import { requestCityweftData, downloadFile, fetchGeometryJson, GeometryResponse } from './services/api';
import MapViewer from './components/MapViewer';
import ControlPanel from './components/ControlPanel';
import ModelPreview from './components/ModelPreview';

const ApiKeyModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  apiKey: string;
  setApiKey: (val: string) => void;
  nanoBananaApiKey: string;
  setNanoBananaApiKey: (val: string) => void;
}> = ({ isOpen, onClose, apiKey, setApiKey, nanoBananaApiKey, setNanoBananaApiKey }) => {
  const [showKey, setShowKey] = useState(false);
  const [showNanoKey, setShowNanoKey] = useState(false);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[2000] flex items-center justify-center p-6 bg-slate-950/60 backdrop-blur-md animate-in fade-in duration-300">
      <div
        className="glass-panel w-full max-w-md rounded-[40px] p-10 shadow-2xl border border-white/10 animate-in zoom-in-95 duration-300"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-start mb-8">
          <div>
            <h2 className="text-xl font-black text-white tracking-tight flex items-center gap-3">
              <Key className="w-6 h-6 text-blue-500" />
              Credentials
            </h2>
            <p className="text-[10px] text-slate-500 font-bold uppercase tracking-[0.2em] mt-2">Authentication Required</p>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-white/5 rounded-full text-slate-500 hover:text-white transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-6">
          {/* Cityweft API Key */}
          <div className="space-y-3">
            <label className="text-[11px] font-black text-slate-400 uppercase tracking-widest px-1">Cityweft API Key</label>
            <div className="relative group">
              <input
                type={showKey ? "text" : "password"}
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                placeholder="cw_live_..."
                className="w-full bg-slate-900/50 border border-white/10 rounded-2xl px-6 py-5 text-sm font-mono text-white placeholder:text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-600/50 transition-all"
              />
              <button
                onClick={() => setShowKey(!showKey)}
                className="absolute right-5 top-1/2 -translate-y-1/2 text-slate-600 hover:text-white transition-colors p-1"
              >
                {showKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* NanoBanana API Key */}
          <div className="space-y-3">
            <label className="text-[11px] font-black text-slate-400 uppercase tracking-widest px-1">Gemini API Key (Optional)</label>
            <div className="relative group">
              <input
                type={showNanoKey ? "text" : "password"}
                value={nanoBananaApiKey}
                onChange={(e) => setNanoBananaApiKey(e.target.value)}
                placeholder="sk-..."
                className="w-full bg-slate-900/50 border border-white/10 rounded-2xl px-6 py-5 text-sm font-mono text-white placeholder:text-slate-700 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 transition-all"
              />
              <button
                onClick={() => setShowNanoKey(!showNanoKey)}
                className="absolute right-5 top-1/2 -translate-y-1/2 text-slate-600 hover:text-white transition-colors p-1"
              >
                {showNanoKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            <p className="text-[10px] text-slate-500 px-1">Required for rendering detailed views.</p>
          </div>

          <div className="p-5 rounded-3xl bg-blue-500/5 border border-blue-500/10">
            <div className="flex gap-4">
              <ShieldCheck className="w-5 h-5 text-blue-500 shrink-0" />
              <p className="text-[11px] font-medium leading-relaxed text-slate-400">
                Keys are stored locally in your browser. They are only used to authenticate requests.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-full py-5 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white font-black text-xs uppercase tracking-[0.2em] transition-all shadow-xl shadow-blue-600/20 active:scale-[0.98]"
          >
            Save Credentials
          </button>
        </div>
      </div>
    </div>
  );
};

const App: React.FC = () => {
  const [apiKey, setApiKey] = useState<string>(localStorage.getItem('cityweft_api_key') || '');
  const [nanoBananaApiKey, setNanoBananaApiKey] = useState<string>(localStorage.getItem('nanobanana_api_key') || '');

  useEffect(() => {
    localStorage.setItem('cityweft_api_key', apiKey);
  }, [apiKey]);

  useEffect(() => {
    localStorage.setItem('nanobanana_api_key', nanoBananaApiKey);
  }, [nanoBananaApiKey]);

  const [showApiModal, setShowApiModal] = useState(false);
  const [status, setStatus] = useState<AppStatus>(AppStatus.IDLE);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [progress, setProgress] = useState<number>(0);
  const [selectedPolygon, setSelectedPolygon] = useState<[number, number][] | null>(null);
  const [areaKm2, setAreaKm2] = useState<number>(0);
  const [mapFlyTo, setMapFlyTo] = useState<[number, number] | null>(null);
  const [clearTrigger, setClearTrigger] = useState<number>(0);

  const [searchQuery, setSearchQuery] = useState('');
  const [suggestions, setSuggestions] = useState<any[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);

  // Preview modal state
  const [showPreview, setShowPreview] = useState(false);
  const [previewData, setPreviewData] = useState<GeometryResponse | null>(null);
  const [isLoadingPreview, setIsLoadingPreview] = useState(false);

  const [settings, setSettings] = useState<AppSettings>({
    geometry: ['buildings', 'surface', 'infrastructure'],
    crs: 'local',
    cropScene: true,
    disableSurfaceProjection: false,
    topographyModel: false,
    topographyReturnType: null,
    defaultRoofType: 'flat'
  });

  const [exportConfig, setExportConfig] = useState<{ format: ExportFormat; version: number | null; filename: string }>({
    format: 'skp',
    version: null,
    filename: ''
  });

  useEffect(() => {
    localStorage.setItem('cityweft_api_key', apiKey);
  }, [apiKey]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setShowSuggestions(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    if (!searchQuery || searchQuery.length < 1) {
      setSuggestions([]);
      setShowSuggestions(false);
      return;
    }

    const delayDebounceFn = setTimeout(async () => {
      setIsSearching(true);
      try {
        const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(searchQuery)}&limit=5`);
        const data = await response.json();
        setSuggestions(data);
        setShowSuggestions(true);
      } catch (e) {
        console.error("Suggestion fetch failed", e);
      } finally {
        setIsSearching(false);
      }
    }, 50);

    return () => clearTimeout(delayDebounceFn);
  }, [searchQuery]);

  const handleSelectLocation = (lat: string, lon: string, displayName: string) => {
    setMapFlyTo([parseFloat(lat), parseFloat(lon)]);
    setSearchQuery(displayName);
    setShowSuggestions(false);
  };

  const handleClearSelection = () => {
    setClearTrigger(prev => prev + 1);
    setSelectedPolygon(null);
    setAreaKm2(0);
  };

  const handlePolygonChange = useCallback((coords: [number, number][], area: number) => {
    setSelectedPolygon(coords);
    setAreaKm2(area);
  }, []);

  /**
   * Preview the model before downloading
   */
  const handlePreview = async () => {
    if (!apiKey || !selectedPolygon) {
      if (!apiKey) {
        setErrorMessage("Cityweft API Key is required.");
        setShowApiModal(true);
      }
      return;
    }

    setIsLoadingPreview(true);
    setShowPreview(true);
    setErrorMessage(null);

    try {
      const payload = {
        polygon: selectedPolygon,
        settings: {
          ...settings,
          topographyReturnType: (settings.topographyModel ? 'elevationMap' : null) as 'elevationMap' | null
        }
      };

      const geometryData = await fetchGeometryJson(payload, apiKey);
      setPreviewData(geometryData);
    } catch (err: any) {
      setErrorMessage(err.message || "Failed to load preview.");
      setShowPreview(false);
    } finally {
      setIsLoadingPreview(false);
    }
  };

  /**
   * Download the model after preview confirmation
   */
  const handleDownloadFromPreview = async () => {
    setShowPreview(false);
    await handleDownload();
  };

  /**
   * Direct download without preview
   */
  const handleDownload = async () => {
    if (!apiKey || !selectedPolygon) {
      if (!apiKey) {
        setErrorMessage("Cityweft API Key is required.");
        setShowApiModal(true);
      }
      return;
    }

    setStatus(AppStatus.PREPARING);
    setProgress(5);
    setErrorMessage(null);

    try {
      const payload: CityweftPayload = {
        polygon: selectedPolygon,
        settings: {
          ...settings,
          topographyReturnType: settings.topographyModel ? 'elevationMap' : null
        },
        export: {
          format: exportConfig.format === 'rhino' ? '3dm' as any : exportConfig.format,
          version: exportConfig.version
        },
        requestId: crypto.randomUUID(),
        timestamp: Date.now()
      };

      setProgress(20);
      setStatus(AppStatus.REQUESTING);
      const downloadUrl = await requestCityweftData(payload, apiKey);

      setProgress(50);
      setStatus(AppStatus.PROCESSING);
      const ext = exportConfig.format === 'rhino' ? '3dm' : exportConfig.format;
      const finalFilename = `${exportConfig.filename || 'cityweft_' + Date.now()}.${ext}`;

      setStatus(AppStatus.DOWNLOADING);
      setProgress(80);
      await downloadFile(downloadUrl, finalFilename);

      setProgress(100);
      setStatus(AppStatus.SUCCESS);
      setTimeout(() => { setStatus(AppStatus.IDLE); setProgress(0); }, 5000);
    } catch (err: any) {
      setStatus(AppStatus.ERROR);
      setErrorMessage(err.message || "Extraction failed.");
    }
  };

  return (
    <div className="relative h-screen w-screen bg-[#020617] flex overflow-hidden selection:bg-blue-500/30">
      {/* Floating Search Hub */}
      <div className="absolute top-8 left-8 z-[1400] w-[440px] h-12 pointer-events-none" ref={searchRef}>
        <div className="glass-panel rounded-[32px] p-1 flex items-center shadow-[0_32px_64px_-12px_rgba(0,0,0,0.5)] pointer-events-auto transition-all duration-500 hover:ring-2 hover:ring-blue-500/20 focus-within:ring-2 focus-within:ring-blue-500/50">
          <div className="flex items-center gap-3 px-3 py-1.5 flex-grow min-w-0">
            {isSearching ? <Loader2 className="w-5 h-5 text-blue-400 animate-spin" /> : <Search className="w-5 h-5 text-slate-500" />}
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Find city..."
              className="bg-transparent border-none outline-none text-sm text-slate-100 placeholder:text-slate-400 w-full font-semibold"
            />
            {searchQuery && (
              <button onClick={() => setSearchQuery('')} className="p-1 hover:bg-white/10 rounded-lg text-slate-500 hover:text-white transition-colors">
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
          <div className="flex items-center gap-1 px-1 border-l border-white/5">
            <button
              onClick={() => {
                navigator.geolocation.getCurrentPosition((pos) => {
                  setMapFlyTo([pos.coords.latitude, pos.coords.longitude]);
                });
              }}
              className="p-2 hover:bg-white/10 rounded-2xl transition-all text-slate-500 hover:text-blue-400 active:scale-90"
            >
              <Navigation className="w-5 h-5" />
            </button>
          </div>
        </div>

        {showSuggestions && suggestions.length > 0 && (
          <div className="absolute top-0 left-[450px] w-[300px] glass-panel !bg-slate-800/90 rounded-[24px] overflow-hidden shadow-2xl pointer-events-auto border border-white/10 animate-in fade-in slide-in-from-left-4 duration-500">
            {suggestions.map((item, index) => (
              <button
                key={index}
                onClick={() => handleSelectLocation(item.lat, item.lon, item.display_name)}
                className="w-full text-left px-6 py-4 hover:bg-blue-500/10 transition-colors flex flex-col group border-b border-white/5 last:border-none"
              >
                <div className="flex flex-col min-w-0">
                  <span className="text-sm text-white font-bold truncate group-hover:text-blue-400 transition-colors">{item.display_name}</span>
                  <span className="text-[10px] text-slate-500 uppercase tracking-widest font-black mt-1 group-hover:text-blue-400/70 transition-colors">{item.type || 'Location'}</span>
                </div>
              </button>
            ))}
          </div>
        )}
      </div>

      <ControlPanel
        settings={settings}
        setSettings={setSettings}
        exportConfig={exportConfig}
        setExportConfig={setExportConfig}
        status={status}
        progress={progress}
        errorMessage={errorMessage}
        onDownload={handleDownload}
        onPreview={handlePreview}
        selectedArea={areaKm2}
        onClearSelection={handleClearSelection}
        canDownload={!!selectedPolygon && areaKm2 > 0 && areaKm2 <= 5 && !!apiKey}
        onOpenApiKeyModal={() => setShowApiModal(true)}
        hasApiKey={!!apiKey}
      />

      {/* API Key Modal */}
      <ApiKeyModal
        isOpen={showApiModal}
        onClose={() => setShowApiModal(false)}
        apiKey={apiKey}
        setApiKey={setApiKey}
        nanoBananaApiKey={nanoBananaApiKey}
        setNanoBananaApiKey={setNanoBananaApiKey}
      />

      {/* Model Preview Modal */}
      <ModelPreview
        isOpen={showPreview}
        onClose={() => {
          setShowPreview(false);
          setPreviewData(null);
        }}
        geometryData={previewData}
        onConfirmDownload={handleDownloadFromPreview}
        isLoading={isLoadingPreview}
        nanoBananaApiKey={nanoBananaApiKey}
        locationName={searchQuery}
      />

      <main className="flex-grow relative h-full">
        <MapViewer
          onPolygonChange={handlePolygonChange}
          flyTo={mapFlyTo}
          clearTrigger={clearTrigger}
        />
      </main>
    </div>
  );
};

export default App;
